@echo off
chcp 65001 >nul
title 汽水音乐后端 (qs-backend)
cd /d "%~dp0"
echo ============================================
echo   MuoniumPlayer 汽水音乐签名后端
echo   监听 http://127.0.0.1:8787 (仅本机)
echo   关掉本窗口即停止后端
echo   由游戏启动的实例会随游戏一起退出(任务管理器里显示为 qishui后端 for Muo)
echo ============================================
qishui-backend.exe server.mjs
echo.
echo 后端已退出(上方有日志)。按任意键关闭。
pause >nul
