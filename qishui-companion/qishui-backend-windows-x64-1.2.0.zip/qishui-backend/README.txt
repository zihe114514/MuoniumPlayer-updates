MuoniumPlayer 汽水音乐签名后端(qs-backend)
=============================================

这是什么
--------
汽水音乐的 /luna/pc/* 接口(取完整版歌曲、账号歌单)需要逐请求的应用级
签名头 X-Helios / X-Medusa,只有汽水音乐官方客户端自带的 bdms.node 算得
出来。本服务在本机加载官方客户端的 bdms.node 完成签名,并给 MuoniumPlayer
模组提供搜索 / 歌单 / 推荐 / 取流 / 解密的本地 HTTP 接口。

它监听 127.0.0.1(仅本机),不会把任何端口暴露到局域网。

首次运行
--------
1. 本机需要安装汽水音乐官方客户端(PC 版)——服务要加载它自带的
   resources/app.asar.unpacked/bdms.node。装在任意盘都行,首启自动探测;
   探测不到就在 config.json 里把 client_dir 改成实际安装目录。
2. 双击 start.bat。首启会自动生成 config.json(设备身份等),监听
   http://127.0.0.1:8787。
3. 登录:在游戏里 MuoniumPlayer 的汽水音乐源完成扫码/导入 Cookie,
   模组会把 Cookie 自动推送给本服务;也可以手动 POST /api/cookie 导入。

日常使用
--------
- 保持 start.bat 窗口开着,进游戏即可。后端没开时模组自动降级为试听模式。
- **游戏自动管理**:模组在游戏启动时自动拉起本后端,退出游戏时自动关闭它
  (正常退出、崩溃、任务管理器结束进程都算)。任务管理器里它显示为
  `qishui后端 for Muo`。手动开着 start.bat 的实例不受游戏影响。
- 解密好的音频缓存在 cache/ 目录,同一首歌第二次请求秒回。
- 想开机自启:把 start.bat 的快捷方式放进 shell:startup。

接口一览(127.0.0.1:8787)
--------------------------
GET  /api/health              状态(cookie/设备/客户端路径/pid/版本)
GET  /api/search?q=&limit=    搜索
GET  /api/playlist/:id       歌单详情
GET  /api/related/:trackId   相关推荐
GET  /api/stream/:trackId    取流(签名→下载→解密→缓存)
GET  /api/file/:name         播放已解密文件(支持 Range)
GET  /api/cookie             Cookie 状态
POST /api/cookie              导入 Cookie {"cookie":"..."}
POST /api/pc                  签名 PC 接口白名单代理(仅 /luna/pc/*)

命令行参数(模组拉起时用,手动运行一般不需要)
--------------------------------------------
--watchdog-stdin     父进程消失(stdin 关闭)时自动退出
--parent-pid <pid>   监视指定进程,它不存在时自动退出
两个参数都不给时是常驻服务,不会自己退出(手动 start.bat 就是这个形态)。

声明
----
仅供个人学习与自用,配合本人自己的汽水音乐账号使用;请遵守服务条款,
勿批量抓取或再分发音频。签名组件版权归字节跳动所有,本包不含任何官方
二进制之外的修改。
