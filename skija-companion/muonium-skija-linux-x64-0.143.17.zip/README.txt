Skija 原生库伴生包（MuoniumPlayer）

本包平台：linux-x64（Skija 0.143.17）

把本压缩包里的文件夹整个解压到 Minecraft 的 config/muonium/native/skija/ 下面，
让最终形如：
    config/muonium/native/skija/linux/x64/libskija.*
然后回到游戏，约 20 秒内渲染层会自动重试一次，不需要重启。

已经装好 MuoniumPlayer 主模组即可，不需要动 mods/ 目录。
要不要本包，看模组停用提示第一行：写着「缺 linux-x64 的渲染原生库」就是这个包。

许可：本包内的 libskija 二进制由 Skija（Apache-2.0，见 LICENSE-Skija.txt 与 NOTICE-Skija.txt）
构建自 Skia（BSD-3-Clause，见 LICENSE-Skia.txt）。请连同这两个许可文本一起保留。
