# -*- coding: utf-8 -*-
"""amp_api.py —— Java 侧 AMP API 请求的 Python 助手。

背景：amp-api.music.apple.com 按 TLS/JA3 指纹拒绝 Java 客户端（Java 25 的
HttpURLConnection 打任何端点稳定 401，Python 同凭据同头 200），而本伴生整包
自带完整 Python 栈 —— Java 以子进程调用本脚本，等价于「用 Python 的 TLS 指纹
发请求」。

协议：命令行参数 = 子命令，stdin = JSON 参数，stdout = JSON 结果，stderr = 日志。
所有结果都带 {"ok": true/false, ...}；绝不把 cookie/token 写进 stdout 日志。

子命令：
  probe       {"mediaUserToken": "..."}                       -> {"ok","valid","subscriptionActive"}
  search      {"term": "...", "limit": 30, "storefront": "cn"} -> {"ok","songs":[Track...]}
  libraryPlaylists {"mediaUserToken": "..."}                  -> {"ok","playlists":[Playlist...]}
  libraryPlaylistTracks {"mediaUserToken","playlistId","max"} -> {"ok","tracks":[Track...]}
  librarySongs {"mediaUserToken","max"}                       -> {"ok","tracks":[Track...]}
  playlist    {"playlistId","storefront","max"}                -> {"ok","tracks":[Track...]}
  album       {"albumId","storefront"}                         -> {"ok","tracks":[Track...],"card":{...}}
  ttml        {"songId","storefront","mediaUserToken"}         -> {"ok","ttml":"..."}
  preview     {"songId","storefront","mediaUserToken"}         -> {"ok","previewUrl":"...","name":...}
"""
import base64
import json
import re
import sys
import urllib.error
from http.cookiejar import MozillaCookieJar

AMP = "https://amp-api.music.apple.com"
HOMEPAGE = "https://music.apple.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36")

BUNDLE_RE = re.compile(r'/(assets/index[~-][^/"]+\.js)')
TOKEN_RE = re.compile(r'[\'"](eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)[\'"]')


def fail(message, **extra):
    return {"ok": False, "error": message, **extra}


def http_get(url, headers=None, timeout=20):
    import urllib.request
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def amp_token():
    """公开 bearer（Java 的 AppleTokenManager 同款逻辑，Python 指纹放行）。"""
    home = http_get(HOMEPAGE)
    bundle = BUNDLE_RE.search(home).group(1)
    js = http_get(HOMEPAGE + "/" + bundle, timeout=40)
    def iss(t):
        p = t.split(".")[1]
        p += "=" * (-len(p) % 4)
        try:
            return json.loads(base64.urlsafe_b64decode(p)).get("iss")
        except Exception:
            return None
    for t in set(TOKEN_RE.findall(js)):
        if iss(t) == "AMPWebPlay":
            return t
    return None


def amp_headers(token, mut=None):
    h = {"Authorization": "Bearer " + token,
         "Origin": HOMEPAGE,
         "Referer": HOMEPAGE + "/",
         "User-Agent": UA}
    if mut:
        h["Media-User-Token"] = mut
    return h


def track_of(resource):
    a = resource.get("attributes") or {}
    out = {
        "id": resource.get("id", ""),
        "name": a.get("name", ""),
        "artist": a.get("artistName", ""),
        "album": a.get("albumName", ""),
        "albumId": a.get("albumId", ""),
        "durationMillis": a.get("durationInMillis") or 0,
        "previewUrl": "",
    }
    art = a.get("artwork") or {}
    if art.get("url"):
        out["coverUrl"] = art["url"].replace("{w}", "600").replace("{h}", "600")
    previews = a.get("previews") or []
    if previews and previews[0].get("url"):
        out["previewUrl"] = previews[0]["url"]
    ext = a.get("extendedAssetUrls") or {}
    if not out["previewUrl"] and ext.get("previewUrl"):
        out["previewUrl"] = ext["previewUrl"]
    # library 行：playParams.catalogId 才是 catalog 主键（gamdl/preview 认它）
    if str(out["id"]).startswith("i."):
        catalog_id = ((a.get("playParams") or {}).get("catalogId") or "")
        out["id"] = catalog_id or ""
    return out if out["id"] and out["name"] else None


def playlist_of(resource, owner_fallback):
    a = resource.get("attributes") or {}
    name = a.get("name", "")
    if not name:
        return None
    art = a.get("artwork") or {}
    return {
        "id": resource.get("id", ""),
        "name": name,
        "owner": a.get("curatorName") or a.get("artistName") or owner_fallback,
        "trackCount": a.get("trackCount") or 0,
        "coverUrl": (art.get("url") or "").replace("{w}", "300").replace("{h}", "300"),
    }


def cmd_probe(args):
    mut = args.get("mediaUserToken", "")
    token = amp_token()
    d = json.loads(http_get(AMP + "/v1/me/account?meta=subscription&l=zh-Hans-CN",
                            amp_headers(token, mut)))
    sub = (d.get("meta") or {}).get("subscription") or {}
    return {"ok": True, "valid": True,
            "subscriptionActive": bool(sub.get("active")),
            "storefront": sub.get("storefront", "")}


def cmd_search(args):
    term, limit, sf = args.get("term", ""), int(args.get("limit", 30)), args.get("storefront", "cn")
    token = amp_token()
    from urllib.parse import quote
    d = json.loads(http_get(
        f"{AMP}/v1/catalog/{sf}/search?term={quote(term)}&types=songs&limit={limit}&l=zh-Hans-CN",
        amp_headers(token)))
    songs = []
    for r in (d.get("results", {}).get("songs", {}).get("data") or []):
        t = track_of(r)
        if t:
            songs.append(t)
    return {"ok": True, "songs": songs}


def cmd_library_playlists(args):
    mut = args.get("mediaUserToken", "")
    token = amp_token()
    out, offset = [], 0
    while offset < 500:
        d = json.loads(http_get(
            f"{AMP}/v1/me/library/playlists?limit=100&offset={offset}&l=zh-Hans-CN",
            amp_headers(token, mut)))
        page = d.get("data") or []
        if not page:
            break
        for r in page:
            p = playlist_of(r, "我的 Apple 歌单")
            if p:
                out.append(p)
        offset += len(page)
    return {"ok": True, "playlists": out}


def _get_amp_json(url, mut):
    """AMP GET；404 视为「无更多数据」返回 None（资料库端点 offset 越界返回 404
    而不是空列表 —— catalog 是空 data，资料库是 404，实机踩中），其余状态照抛。"""
    try:
        return json.loads(http_get(url, amp_headers(_token_cached(), mut)))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


_TOKEN = {"value": None}


def _token_cached():
    if not _TOKEN["value"]:
        _TOKEN["value"] = amp_token()
    return _TOKEN["value"]


def _library_tracks(url, mut, max_items):
    out, offset = [], 0
    while len(out) < max_items:
        limit = min(100, max_items - len(out))
        page = _get_amp_json(f"{url}?limit={limit}&offset={offset}&l=zh-Hans-CN", mut)
        # None = 越界 404：资料库的「没有更多页」形态，正常收尾。
        data = (page or {}).get("data") or []
        if not data:
            break
        before = len(out)
        for r in data:
            t = track_of(r)
            if t:
                out.append(t)
        if len(out) == before:
            break
        offset += len(data)
        if offset >= 2000:
            break
    return out


def cmd_library_playlist_tracks(args):
    tracks = _library_tracks(
        f"{AMP}/v1/me/library/playlists/{args.get('playlistId', '')}/tracks",
        args.get("mediaUserToken", ""), int(args.get("max", 100)))
    return {"ok": True, "tracks": tracks}


def cmd_library_songs(args):
    tracks = _library_tracks(f"{AMP}/v1/me/library/songs",
                             args.get("mediaUserToken", ""), int(args.get("max", 100)))
    return {"ok": True, "tracks": tracks}


def cmd_playlist(args):
    pid, sf, max_items = args.get("playlistId", ""), args.get("storefront", "cn"), int(args.get("max", 300))
    token = amp_token()
    d = json.loads(http_get(
        f"{AMP}/v1/catalog/{sf}/playlists/{pid}?extend=extendedAssetUrls&l=zh-Hans-CN",
        amp_headers(token)))
    data = d.get("data") or []
    tracks = []
    if data:
        rel = data[0].get("relationships") or {}
        for r in (rel.get("tracks", {}).get("data") or []):
            t = track_of(r)
            if t:
                tracks.append(t)
        nxt = rel.get("next")
        while nxt and len(tracks) < max_items:
            page = json.loads(http_get(AMP + nxt if nxt.startswith("/") else nxt,
                                       amp_headers(token)))
            pdata = page.get("data") or []
            if not pdata:
                break
            before = len(tracks)
            for r in pdata:
                t = track_of(r)
                if t:
                    tracks.append(t)
            if len(tracks) == before:
                break
            nxt = page.get("next")
    return {"ok": True, "tracks": tracks}


def cmd_album(args):
    aid, sf = args.get("albumId", ""), args.get("storefront", "cn")
    token = amp_token()
    d = json.loads(http_get(
        f"{AMP}/v1/catalog/{sf}/albums/{aid}?extend=extendedAssetUrls&l=zh-Hans-CN",
        amp_headers(token)))
    data = d.get("data") or []
    if not data:
        return fail("album not found")
    card = playlist_of(data[0], "Apple Music 专辑")
    tracks = []
    for r in ((data[0].get("relationships") or {}).get("tracks", {}).get("data") or []):
        t = track_of(r)
        if t:
            if not t.get("album"):
                t["album"] = (card or {}).get("name", "")
            tracks.append(t)
    return {"ok": True, "tracks": tracks, "card": card}


def cmd_ttml(args):
    sid, sf, mut = args.get("songId", ""), args.get("storefront", "cn"), args.get("mediaUserToken", "")
    token = amp_token()
    d = json.loads(http_get(
        f"{AMP}/v1/catalog/{sf}/songs/{sid}?include=lyrics&extend=extendedAssetUrls&l=zh-Hans-CN",
        amp_headers(token, mut)))
    data = d.get("data") or []
    if not data:
        return {"ok": True, "ttml": ""}
    rel = (data[0].get("relationships") or {}).get("lyrics", {}).get("data") or []
    for r in rel:
        ttml = (r.get("attributes") or {}).get("ttml", "")
        if ttml:
            return {"ok": True, "ttml": ttml}
    return {"ok": True, "ttml": ""}


def cmd_preview(args):
    sid, sf, mut = args.get("songId", ""), args.get("storefront", "cn"), args.get("mediaUserToken", "")
    token = amp_token()
    d = json.loads(http_get(
        f"{AMP}/v1/catalog/{sf}/songs/{sid}?extend=extendedAssetUrls&l=zh-Hans-CN",
        amp_headers(token, mut)))
    data = d.get("data") or []
    if not data:
        return {"ok": True, "previewUrl": "", "name": ""}
    a = data[0].get("attributes") or {}
    url = ""
    for p in (a.get("previews") or []):
        if p.get("url"):
            url = p["url"]
            break
    if not url and (a.get("extendedAssetUrls") or {}).get("previewUrl"):
        url = a["extendedAssetUrls"]["previewUrl"]
    return {"ok": True, "previewUrl": url, "name": a.get("name", "")}


COMMANDS = {
    "probe": cmd_probe,
    "search": cmd_search,
    "libraryPlaylists": cmd_library_playlists,
    "libraryPlaylistTracks": cmd_library_playlist_tracks,
    "librarySongs": cmd_library_songs,
    "playlist": cmd_playlist,
    "album": cmd_album,
    "ttml": cmd_ttml,
    "preview": cmd_preview,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(json.dumps(fail("unknown command; first arg must be one of: "
                              + ", ".join(sorted(COMMANDS)))))
        return 2
    try:
        args = json.loads(sys.stdin.read() or "{}")
        result = COMMANDS[sys.argv[1]](args)
    except Exception as exc:  # noqa: BLE001 —— 任何失败都以 JSON 形态回给 Java
        print(json.dumps(fail(f"{type(exc).__name__}: {exc}")))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
